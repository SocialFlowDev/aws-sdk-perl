package Paws::JsonParamsService::Object;
  use Moose;
  has Att1 => (is => 'ro', isa => 'Str');
  has Att2 => (is => 'ro', isa => 'Str');
1;
