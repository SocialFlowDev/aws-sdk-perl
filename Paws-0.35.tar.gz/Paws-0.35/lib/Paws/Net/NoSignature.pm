package Paws::Net::NoSignature;
  use Moose::Role;

  sub sign {
  }
1;
