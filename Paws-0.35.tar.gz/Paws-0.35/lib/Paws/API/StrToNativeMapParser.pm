package Paws::API::StrToNativeMapParser;
  use Moose::Role;

1;
