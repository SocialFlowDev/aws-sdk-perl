package Paws::API::MapParser;
  use Moose::Role;

1;
